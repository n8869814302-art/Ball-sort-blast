package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.logic.BallSortLogic
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Ball Sort Blast", appName)
    }

    @Test
    fun `verify ball sort move logic`() {
        val fromTube = listOf(0, 1, 2)
        val toEmptyTube = emptyList<Int>()
        val toMatchingTube = listOf(1, 2)
        val toMismatchTube = listOf(1, 3)
        val toFullTube = listOf(2, 2, 2, 2, 2, 2, 2)

        assertTrue(BallSortLogic.canMove(fromTube, toEmptyTube))
        assertTrue(BallSortLogic.canMove(fromTube, toMatchingTube))
        assertFalse(BallSortLogic.canMove(fromTube, toMismatchTube))
        assertFalse(BallSortLogic.canMove(fromTube, toFullTube))
    }

    @Test
    fun `verify tube completion and solved level detection`() {
        val completedTube = List(7) { 3 }
        val incompleteTube = List(6) { 3 }
        val mixedTube = listOf(3, 3, 3, 3, 3, 3, 2)

        assertTrue(BallSortLogic.isTubeComplete(completedTube))
        assertFalse(BallSortLogic.isTubeComplete(incompleteTube))
        assertFalse(BallSortLogic.isTubeComplete(mixedTube))

        val solvedState = listOf(List(7) { 0 }, List(7) { 1 }, emptyList())
        assertTrue(BallSortLogic.isLevelSolved(solvedState))

        val unsolvedState = listOf(List(6) { 0 }, List(6) { 1 }, listOf(1))
        assertFalse(BallSortLogic.isLevelSolved(unsolvedState))
    }

    @Test
    fun `verify number of tubes changes in every next level`() {
        for (lvl in 2..50) {
            val prev = BallSortLogic.getLevelTubeSetup(lvl - 1)
            val curr = BallSortLogic.getLevelTubeSetup(lvl)
            val prevTotal = prev.first + prev.second
            val currTotal = curr.first + curr.second
            assertTrue("Level $lvl ($currTotal tubes) should have different tube count from level ${lvl - 1} ($prevTotal tubes)", prevTotal != currTotal)
        }
    }

    @Test
    fun `verify level generation preserves empty tubes and opening moves work`() {
        for (lvl in 1..10) {
            val (colors, emptyCount) = BallSortLogic.getLevelTubeSetup(lvl)
            val tubes = BallSortLogic.generateLevel(lvl)
            assertEquals("Level $lvl total tubes mismatch", colors + emptyCount, tubes.size)

            val emptyTubesFound = tubes.count { it.isEmpty() }
            assertTrue("Level $lvl must have at least $emptyCount empty tubes at start, found $emptyTubesFound", emptyTubesFound >= emptyCount)

            // Test that a ball from a non-empty tube can move to an empty tube
            val nonEmptyIdx = tubes.indexOfFirst { it.isNotEmpty() }
            val emptyIdx = tubes.indexOfFirst { it.isEmpty() }

            assertTrue("Must have non-empty tube", nonEmptyIdx != -1)
            assertTrue("Must have empty tube", emptyIdx != -1)

            val sourceTube = tubes[nonEmptyIdx]
            val destTube = tubes[emptyIdx]

            assertTrue(BallSortLogic.canMove(sourceTube, destTube))

            // Test that executePour actually moves the ball
            val mutableTubes = tubes.map { it.toMutableList() }.toMutableList()
            val initialSourceSize = mutableTubes[nonEmptyIdx].size
            val moved = BallSortLogic.executePour(mutableTubes, nonEmptyIdx, emptyIdx)

            assertTrue(moved > 0)
            assertEquals(initialSourceSize - moved, mutableTubes[nonEmptyIdx].size)
            assertEquals(moved, mutableTubes[emptyIdx].size)
        }
    }

    @Test
    fun `verify BFS solver finds hint and solution`() {
        // Simple 2-color puzzle with 1 empty tube
        val puzzle = listOf(
            listOf(0, 0, 1),
            listOf(1, 1, 0),
            emptyList()
        )
        val solution = BallSortLogic.solvePuzzle(puzzle, capacity = 3)
        assertTrue(solution != null)
        assertTrue(solution!!.isNotEmpty())

        val hint = BallSortLogic.findHint(puzzle)
        assertTrue(hint != null)
    }
}
