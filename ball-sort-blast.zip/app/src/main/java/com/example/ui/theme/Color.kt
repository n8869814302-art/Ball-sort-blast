package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberCyan = Color(0xFF00E5FF)
val NeonPink = Color(0xFFFF2A55)
val LaserYellow = Color(0xFFFFEA00)
val AcidGreen = Color(0xFF00E676)
val DeepSpace = Color(0xFF0D1024)
val DarkSurface = Color(0xFF181B38)
val DarkSurfaceVariant = Color(0xFF23274E)
val TextMuted = Color(0xFF8D93B8)
